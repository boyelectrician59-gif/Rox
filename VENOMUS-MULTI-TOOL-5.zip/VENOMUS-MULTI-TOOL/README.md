# VENOMUS Multi-Tool

Responsive URL shortener, QR generator, Code 128 barcode generator, browser-local history, and optional Telegram bot/admin notifications.

## Requirements
- Node.js 20+
- Telegram bot token only if using Telegram features

## Local run
1. Copy `.env.example` to `.env`.
2. Add secrets and settings as needed.
3. Install and start the web app:
   ```bash
   npm install
   npm start
   ```
4. Open `http://localhost:3000`.

To run the Telegram bot separately:
```bash
cd bot
npm install
# Copy the root .env values into bot/.env, or run with the root env loaded by your process manager.
npm start
```
Set `WEBSITE_URL` to your deployed site and `TELEGRAM_BOT_USERNAME` without the `@`.

## Deploy to Vercel
- Import this repository into Vercel.
- Add environment variables from `.env.example` in Project Settings.
- The `api/` handlers are Vercel serverless functions. The static site is `index.html`.
- The `server.js` file is for local/Node hosting; Vercel routes `api/*.js` automatically.

## Deploy to Render / Node hosting
- Build command: `npm install`
- Start command: `npm start`
- Add environment variables in the service dashboard.
- The bot can be a separate worker/service with root directory `bot` and start command `npm start`; configure `TELEGRAM_BOT_TOKEN` and `WEBSITE_URL`.

## Telegram setup
1. Create a bot using Telegram's official BotFather.
2. Put the token into `TELEGRAM_BOT_TOKEN` in your host's environment settings, never in browser code or a public repository.
3. Set `TELEGRAM_BOT_USERNAME` to the bot username without `@`.
4. Run the bot worker for `/start`, `/help`, `/tools`, `/shorten`, `/qr`, and `/barcode`.
5. For admin alerts, set `TELEGRAM_ADMIN_CHAT_ID` and `ADMIN_NOTIFICATIONS=true`. The browser admin-notification toggle is intentionally off by default: in browser developer console, a user could manipulate client state, so for a public production service replace it with server-side consent/authentication and rate limiting.
6. The website's “Send to Telegram” endpoint uses `TELEGRAM_DEFAULT_CHAT_ID` as a simple single-chat destination. It is **not** per-user account linking. Do not set this to an admin chat for public use. For per-user delivery, implement Telegram Login Widget or deep-link account linking with one-time expiring tokens, persist the verified Telegram chat ID server-side, and enforce ownership/rate limits.

## Security notes
- Rotate any token previously pasted into chats or public code.
- Keep `.env` out of Git.
- Configure rate limiting at the hosting layer or add a durable rate limiter before public production use.
- Public APIs receive user inputs: TinyURL gets the URL, QRServer gets QR data, and TEC-IT gets barcode data.
- Admin notifications may include input/result snippets; use only with clear notice and consent.
- Never log secrets. Use HTTPS in production.
