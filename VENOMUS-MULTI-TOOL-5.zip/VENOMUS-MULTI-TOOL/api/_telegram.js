export async function telegram(method, payload) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) throw new Error("Telegram bot is not configured on the server.");
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload), signal: AbortSignal.timeout(10000)
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error("Telegram API request failed.");
  return data.result;
}
export function jsonBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  try { return JSON.parse(req.body || "{}"); } catch { return {}; }
}
export function validChatId(value) {
  return typeof value === "string" && /^-?\d{1,20}$/.test(value);
}