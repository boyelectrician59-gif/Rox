import { telegram, jsonBody } from "../_telegram.js";
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const body = jsonBody(req);
    const result = typeof body.result === "string" ? body.result : "";
    if (!result || result.length > 5000) return res.status(400).json({ error: "Invalid result." });
    // Sending is opt-in and only available after a Telegram chat ID is linked/configured.
    const chatId = process.env.TELEGRAM_DEFAULT_CHAT_ID;
    if (!chatId) return res.status(400).json({ error: "To send results, configure TELEGRAM_DEFAULT_CHAT_ID or implement per-user account linking." });
    await telegram("sendMessage", { chat_id: chatId, text: `🐍 VENOMUS Multi-Tool\n\nYour result:\n${result.slice(0, 3500)}`, disable_web_page_preview: true });
    return res.status(200).json({ message: "Sent to the configured Telegram chat." });
  } catch (error) { return res.status(502).json({ error: error.message || "Telegram send failed." }); }
}