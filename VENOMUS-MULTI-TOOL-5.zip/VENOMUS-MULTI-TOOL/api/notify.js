import { telegram, jsonBody, validChatId } from "./_telegram.js";
const rate = new Map();
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  if (process.env.ADMIN_NOTIFICATIONS !== "true") return res.status(200).json({ ok: true, disabled: true });
  try {
    const body = jsonBody(req);
    if (body.consent !== true) return res.status(400).json({ error: "Explicit consent required." });
    const chatId = process.env.TELEGRAM_ADMIN_CHAT_ID || "";
    if (!validChatId(chatId)) return res.status(500).json({ error: "Admin chat is not configured." });
    const type = String(body.type || "Tool").slice(0, 40);
    const input = String(body.input || "").slice(0, 160);
    const result = String(body.result || "").slice(0, 300);
    if (!["URL Shortener", "QR Generator", "Barcode Generator"].includes(type)) return res.status(400).json({ error: "Unknown tool type." });
    await telegram("sendMessage", { chat_id: chatId, text: `🐍 VENOMUS ACTIVITY\nTool: ${type}\nInput: ${input}\nResult: ${result}\nTime: ${new Date().toISOString()}`, disable_web_page_preview: true });
    return res.status(200).json({ ok: true });
  } catch (error) { return res.status(502).json({ error: error.message || "Notification failed." }); }
}