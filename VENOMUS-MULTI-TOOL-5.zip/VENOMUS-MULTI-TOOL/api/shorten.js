export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const { url } = req.body || {};
    if (typeof url !== "string" || url.length > 5000) return res.status(400).json({ error: "Provide a valid URL." });
    let parsed; try { parsed = new URL(url); } catch { return res.status(400).json({ error: "Invalid URL." }); }
    if (!["http:", "https:"].includes(parsed.protocol)) return res.status(400).json({ error: "Only HTTP/HTTPS URLs are supported." });
    const upstream = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(parsed.href)}`, { signal: AbortSignal.timeout(10000) });
    if (!upstream.ok) return res.status(502).json({ error: "Shortener service is temporarily unavailable." });
    const shortUrl = (await upstream.text()).trim();
    let result; try { result = new URL(shortUrl); } catch { return res.status(502).json({ error: "Shortener returned an invalid response." }); }
    if (result.protocol !== "https:" || result.hostname !== "tinyurl.com") return res.status(502).json({ error: "Unexpected shortener response." });
    return res.status(200).json({ shortUrl: result.href });
  } catch { return res.status(502).json({ error: "Could not reach the shortener service." }); }
}