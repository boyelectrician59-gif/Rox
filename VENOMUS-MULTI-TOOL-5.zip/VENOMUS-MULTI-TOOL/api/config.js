export default function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  res.status(200).json({ botUsername: process.env.TELEGRAM_BOT_USERNAME || "" });
}