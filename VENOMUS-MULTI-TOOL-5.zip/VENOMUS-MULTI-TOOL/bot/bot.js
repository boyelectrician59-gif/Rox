import "dotenv/config";
import TelegramBot from "node-telegram-bot-api";
const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) { console.error("Missing TELEGRAM_BOT_TOKEN"); process.exit(1); }
const bot = new TelegramBot(token, { polling: true });
const web = (process.env.WEBSITE_URL || "").replace(/\/$/, "");
const keyboard = { reply_markup: { inline_keyboard: [
  [{ text: "🔗 URL Shortener", url: web || "https://example.com" }],
  [{ text: "📱 QR Generator", url: web || "https://example.com" }, { text: "🏷️ Barcode", url: web || "https://example.com" }],
  [{ text: "🌐 Open Website", url: web || "https://example.com" }]
]}};
bot.onText(/^\/start(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id,
  "🐍 Welcome to VENOMUS Multi-Tool Bot!\n\nShorten URLs, generate QR codes and create Code 128 barcodes on the website.\n\nUse /help for commands.", keyboard));
bot.onText(/^\/help(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id,
  "Commands:\n/start — Welcome menu\n/help — Help\n/tools — Open tool menu\n\nFor creating results, open the website using the menu below.", keyboard));
bot.onText(/^\/tools(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id, "Choose a tool:", keyboard));
bot.onText(/^\/shorten(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id, "Open the website to shorten a URL.", keyboard));
bot.onText(/^\/qr(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id, "Open the website to create a QR code.", keyboard));
bot.onText(/^\/barcode(?:@\w+)?$/, msg => bot.sendMessage(msg.chat.id, "Open the website to create a barcode.", keyboard));
bot.on("polling_error", err => console.error("Telegram polling error:", err.message));
console.log("VENOMUS bot is running.");
